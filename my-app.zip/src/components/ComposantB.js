import React from 'react'
import ComposantD from './ComposantD'

function ComposantB() {
  return (
    <div>
        <ComposantD />
    </div>
  )
}

export default ComposantB