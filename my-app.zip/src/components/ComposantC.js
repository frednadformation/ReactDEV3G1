import React from 'react'
import ComposantE from './ComposantE'

function ComposantC() {
  return (
    <div>
        <ComposantE />
    </div>
  )
}

export default ComposantC