import React from 'react'
import Navbar from '../Navbar/Navbar'

function Home() {
  return (
    <React.Fragment>
    {/* <Navbar /> */}
    
    Bienvenue sur notre super site React !
    
    </React.Fragment>
  )
}

export default Home