import React from 'react'
import ComposantF from './ComposantF'

function ComposantE() {
  return (
    <div>
        <ComposantF />
    </div>
  )
}

export default ComposantE