import React from 'react'
import DataFetchReducer from '../../DataFetchReducer'



function GestionPost() {
  return (
    <div><DataFetchReducer /></div>
  )
}

export default GestionPost